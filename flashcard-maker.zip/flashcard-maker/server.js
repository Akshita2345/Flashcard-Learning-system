// server.js - simple JSON-file backend (no lowdb dependency)
const express = require('express');
const bodyParser = require('body-parser');
const bcrypt = require('bcrypt');
const cors = require('cors');
const { v4: uuidv4 } = require('uuid');
const fs = require('fs').promises;
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(bodyParser.json());
app.use(express.static('public'));

// --- Simple JSON DB implementation ---
const DB_FILE = path.join(__dirname, 'db.json');
let db = {
  users: [],
  flashcards: [],
  questions: [],
  choices: [],
  cards: [],                // simple front/back cards inside a flashcard (deck)
  scores: [],
  answers: []
};

async function loadDb() {
  try {
    const txt = await fs.readFile(DB_FILE, 'utf8');
    const parsed = JSON.parse(txt || '{}');
    // merge defaults so older files still work
    db = Object.assign({
      users: [],
      flashcards: [],
      questions: [],
      choices: [],
      scores: [],
      answers: []
    }, parsed);
  } catch (err) {
    // if file doesn't exist or is invalid, initialize with defaults
    if (err.code === 'ENOENT') {
      await saveDb(); // create file with defaults
    } else {
      console.warn('Warning: failed to read db.json, reinitializing:', err.message);
      await saveDb();
    }
  }
}

async function saveDb() {
  // atomic-ish write: write to temp file then rename
  const tmp = DB_FILE + '.tmp';
  await fs.writeFile(tmp, JSON.stringify(db, null, 2), 'utf8');
  await fs.rename(tmp, DB_FILE);
}

// --- Helpers (previous LowDB helpers preserved semantics) ---
function findUserByEmail(email) { return db.users.find(u => u.email === email); }
function findUserByToken(token) { return db.users.find(u => u.token === token); }

// --- Routes (kept same as your LowDB Option 1) ---
app.post('/api/signup', async (req, res) => {
  try {
    const { name, email, password } = req.body;
    if (!email || !password) return res.status(400).json({ error: 'email and password required' });
    if (findUserByEmail(email)) return res.status(400).json({ error: 'email already in use' });
    const hashed = await bcrypt.hash(password, 10);
    const id = uuidv4();
    db.users.push({ id, name: name || null, email, password_hash: hashed, points: 0 });
    await saveDb();
    res.json({ ok: true, id });
  } catch (e) {
    console.error('signup error', e);
    res.status(500).json({ error: 'internal error' });
  }
});

app.post('/api/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) return res.status(400).json({ error: 'email and password required' });
    const user = findUserByEmail(email);
    if (!user) return res.status(401).json({ error: 'invalid credentials' });
    const ok = await bcrypt.compare(password, user.password_hash);
    if (!ok) return res.status(401).json({ error: 'invalid credentials' });
    const token = uuidv4();
    user.token = token;
    await saveDb();
    res.json({ ok: true, token, user: { id: user.id, name: user.name, email: user.email } });
  } catch (e) {
    console.error('login error', e);
    res.status(500).json({ error: 'internal error' });
  }
});

function authMiddleware(req, res, next) {
  const token = req.headers['x-auth-token'] || req.query.token;
  if (!token) return res.status(401).json({ error: 'no token' });
  const user = findUserByToken(token);
  if (!user) return res.status(401).json({ error: 'invalid token' });
  req.user = user;
  next();
}

app.post('/api/flashcards', authMiddleware, async (req, res) => {
  try {
    const { title, description } = req.body;
    if (!title) return res.status(400).json({ error: 'title required' });
    const id = uuidv4();
    db.flashcards.push({ id, user_id: req.user.id, title, description: description || null, created_at: new Date().toISOString() });
    await saveDb();
    res.json({ ok: true, id });
  } catch (e) {
    console.error('add flashcard error', e);
    res.status(500).json({ error: 'internal error' });
  }
});

// Add simple front/back cards to a flashcard (deck)
app.post('/api/flashcards/:id/cards', authMiddleware, async (req, res) => {
  try {
    const flashcardId = req.params.id;
    const { cards } = req.body; // expect array of { front, back }
    if (!Array.isArray(cards) || cards.length === 0) return res.status(400).json({ error: 'cards required' });
    for (const c of cards) {
      if (!c.front) continue;
      const cid = uuidv4();
      db.cards.push({ id: cid, flashcard_id: flashcardId, front: c.front, back: c.back || '', created_at: new Date().toISOString() });
    }
    await saveDb();
    res.json({ ok: true });
  } catch (e) {
    console.error('add cards error', e);
    res.status(500).json({ error: 'internal error' });
  }
});

app.get('/api/flashcards/:id/cards', authMiddleware, (req, res) => {
  const flashcardId = req.params.id;
  const rows = db.cards.filter(c => c.flashcard_id === flashcardId).map(c => ({ id: c.id, front: c.front, back: c.back }));
  res.json(rows);
});

// Submit answers for front/back cards. Expect answers: [{ cardId, answer }]
app.post('/api/flashcards/:id/cards/submit', authMiddleware, async (req, res) => {
  try {
    const flashcardId = req.params.id;
    const { answers } = req.body;
    if (!Array.isArray(answers)) return res.status(400).json({ error: 'answers required' });
    let correct = 0;
    for (const a of answers) {
      const card = db.cards.find(c => c.id === a.cardId && c.flashcard_id === flashcardId);
      if (!card) continue;
      const expected = (card.back || '').toString().trim().toLowerCase();
      const given = (a.answer || '').toString().trim().toLowerCase();
      const is_correct = (expected.length>0 && expected === given) ? 1 : 0;
      if (is_correct) correct++;
      const aid = uuidv4();
      db.answers.push({ id: aid, user_id: req.user.id, flashcard_id: flashcardId, card_id: card.id, given: a.answer || '', expected: card.back || '', is_correct, created_at: new Date().toISOString() });
    }
    const total = answers.length;
    const sid = uuidv4();
    db.scores.push({ id: sid, user_id: req.user.id, flashcard_id: flashcardId, score: correct, total, created_at: new Date().toISOString() });
    // award 1 point per correct (as requested)
    req.user.points = (req.user.points || 0) + correct;
    await saveDb();
    res.json({ correct, total });
  } catch (e) {
    console.error('submit cards error', e);
    res.status(500).json({ error: 'internal error' });
  }
});

app.get('/api/flashcards', authMiddleware, (req, res) => {
  const rows = db.flashcards
    .filter(f => f.user_id === req.user.id)
    .sort((a, b) => b.created_at.localeCompare(a.created_at))
    .slice(0, 50);
  res.json(rows);
});

app.post('/api/flashcards/:id/questions', authMiddleware, async (req, res) => {
  try {
    const flashcardId = req.params.id;
    const { questions } = req.body;
    if (!Array.isArray(questions) || questions.length === 0) return res.status(400).json({ error: 'questions required' });
    for (const q of questions) {
      const qid = uuidv4();
      db.questions.push({ id: qid, flashcard_id: flashcardId, text: q.question });
      for (let i = 0; i < q.choices.length; i++) {
        const choiceId = uuidv4();
        db.choices.push({ id: choiceId, question_id: qid, text: q.choices[i], is_correct: (i === q.answerIndex) ? 1 : 0 });
      }
    }
    await saveDb();
    res.json({ ok: true });
  } catch (e) {
    console.error('add questions error', e);
    res.status(500).json({ error: 'internal error' });
  }
});

app.get('/api/flashcards/:id/questions', authMiddleware, (req, res) => {
  const flashcardId = req.params.id;
  const qs = db.questions.filter(q => q.flashcard_id === flashcardId);
  const result = qs.map(q => ({
    id: q.id,
    question: q.text,
    choices: db.choices.filter(c => c.question_id === q.id).map(c => ({ id: c.id, text: c.text }))
  }));
  res.json(result);
});

app.post('/api/flashcards/:id/submit', authMiddleware, async (req, res) => {
  try {
    const flashcardId = req.params.id;
    const { answers } = req.body;
    if (!Array.isArray(answers)) return res.status(400).json({ error: 'answers required' });
    let correct = 0;
    for (const a of answers) {
      const choice = db.choices.find(c => c.id === a.choiceId && c.question_id === a.questionId);
      if (choice && choice.is_correct === 1) correct++;
    }
    const total = answers.length;
    const id = uuidv4();
    db.scores.push({ id, user_id: req.user.id, flashcard_id: flashcardId, score: correct, total, created_at: new Date().toISOString() });
    for (const a of answers) {
      const aid = uuidv4();
      const choice = db.choices.find(c => c.id === a.choiceId && c.question_id === a.questionId);
      const is_correct = (choice && choice.is_correct === 1) ? 1 : 0;
      db.answers.push({ id: aid, score_id: id, question_id: a.questionId, choice_id: a.choiceId, is_correct });
    }
    let bonus = 0;
    const pct = total ? (correct / total) : 0;
    if (pct >= 0.9) bonus = 10; else if (pct >= 0.8) bonus = 7; else if (pct >= 0.7) bonus = 5;
    if (bonus > 0) {
      req.user.points = (req.user.points || 0) + bonus;
    }
    await saveDb();
    res.json({ correct, total, bonus });
  } catch (e) {
    console.error('submit answers error', e);
    res.status(500).json({ error: 'internal error' });
  }
});

app.get('/api/wrong-answers', authMiddleware, (req, res) => {
  const rows = db.answers.filter(a => a.is_correct === 0).map(a => ({ question_id: a.question_id, choice_id: a.choice_id, score_id: a.score_id, id: a.id }));
  const out = rows.map(a => ({ id: a.id, question_text: (db.questions.find(q => q.id === a.question_id) || {}).text, chosen_text: (db.choices.find(c => c.id === a.choice_id) || {}).text }));
  res.json(out);
});

app.get('/api/previous', authMiddleware, (req, res) => {
  const scored = db.scores.filter(s => s.user_id === req.user.id).map(s => s.flashcard_id);
  const unique = Array.from(new Set(scored));
  const rows = unique.map(id => {
    const f = db.flashcards.find(x => x.id === id) || {};
    const last = (db.scores.filter(s => s.flashcard_id === id).sort((a, b) => b.created_at.localeCompare(a.created_at))[0] || {}).created_at;
    return { id: f.id, title: f.title, description: f.description, last_revised: last };
  });
  res.json(rows);
});

app.get('/api/scores', authMiddleware, (req, res) => {
  const rows = db.scores.filter(s => s.user_id === req.user.id).sort((a, b) => b.created_at.localeCompare(a.created_at)).slice(0, 50);
  res.json(rows);
});

app.get('/api/points', authMiddleware, (req, res) => {
  res.json({ points: req.user.points || 0 });
});

// --- Start server after loading DB ---
loadDb().then(() => {
  app.listen(PORT, () => console.log('✅ Server running on port', PORT));
}).catch(err => {
  console.error('Failed to initialize DB:', err);
  process.exit(1);
});
